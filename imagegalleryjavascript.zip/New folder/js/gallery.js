const pics = [
    { src: 'images/flowers-pink-large.jpg', alt: 'Pink flowers' },
    { src: 'images/flowers-purple-large.jpg', alt: 'Purple flowers' },
    { src: 'images/flowers-red-large.jpg', alt: 'Red flowers' },
    { src: 'images/flowers-white-large.jpg', alt: 'White flowers' },
    { src: 'images/flowers-yellow-large.jpg', alt: 'Yellow flowers' }
];

const displayedPic = document.querySelector('#displayedPic');
const figcaption = document.getElementById('figcaption');

pics.forEach((pic, index) => {
    const picElement = document.querySelector(`.smallPic${index + 1}`);
    picElement.addEventListener('click', function() {
        displayedPic.setAttribute('src', pic.src);
        figcaption.innerHTML = pic.alt;
    });
});
